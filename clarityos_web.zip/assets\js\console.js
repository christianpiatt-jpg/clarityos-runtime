// Console page — runtime/system dashboard for ClarityOS Cloud v2.4.
//
// Surfaces:
//   • Backend probe         /health              (public)
//   • Runtime configuration /config              (auth)
//   • Environment           browser-derived + window.CLARITYOS_CONFIG
//   • Compute mode          localStorage.clarityos_mode (#c|#C|#G)
//
// The page renders for both authed and anon users. Anon users see the
// public probe and environment block; the runtime card swaps to a
// sign-in CTA. No hard redirects.

document.addEventListener("DOMContentLoaded", () => {
  const placeholderBanner = document.getElementById("placeholder-banner");
  if (window.CLARITYOS_CONFIG.IS_PLACEHOLDER && placeholderBanner) {
    placeholderBanner.classList.remove("hidden");
  }

  paintEnvironment();
  paintComputeMode();
  probeBackend();

  if (ClarityAuth.isSignedIn()) {
    document.getElementById("config-card").classList.remove("hidden");
    document.getElementById("config-anon").classList.add("hidden");
    loadRuntimeConfig();
  } else {
    document.getElementById("config-card").classList.add("hidden");
    document.getElementById("config-anon").classList.remove("hidden");
  }

  // Mode buttons
  document.querySelectorAll("[data-mode]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const mode = btn.dataset.mode;
      try { localStorage.setItem("clarityos_mode", mode); } catch {}
      paintComputeMode();
    });
  });
});

// ---------- Environment (browser/runtime) ----------
function paintEnvironment() {
  const el = document.getElementById("env-info");
  const cfg = window.CLARITYOS_CONFIG;
  el.innerHTML = [
    kv("api base", cfg.API_BASE + (cfg.IS_PLACEHOLDER ? "  (placeholder)" : "")),
    kv("frontend version", cfg.VERSION),
    kv("user agent", navigator.userAgent),
    kv("language", navigator.language || "—"),
    kv("origin", location.origin),
  ].join("");
}

// ---------- Compute mode (#c / #C / #G) ----------
function paintComputeMode() {
  const current = (() => { try { return localStorage.getItem("clarityos_mode"); } catch { return null; } })() || "G";
  document.querySelectorAll("[data-mode]").forEach((btn) => {
    btn.classList.toggle("active", btn.dataset.mode === current);
  });
  const note = document.getElementById("mode-current");
  if (note) {
    const label = { c: "#c — local compute (in-browser stub)", C: "#C — coordinated (local-first, cloud fallback)", G: "#G — cloud compute (Cloud Run engines)" }[current] || current;
    note.textContent = label;
  }
}

// ---------- Backend probe (/health) ----------
async function probeBackend() {
  const pill = document.getElementById("probe-pill");
  const meta = document.getElementById("probe-meta");
  setPill(pill, "idle", "probe");
  meta.textContent = "checking…";
  try {
    const t0 = performance.now();
    const r = await ClarityAPI.health();
    const dt = Math.round(performance.now() - t0);
    setPill(pill, "ok", "ok");
    meta.textContent = `version ${r.version || "?"} · ${dt}ms · ${r.status || ""}`;
  } catch (err) {
    setPill(pill, "err", "down");
    meta.textContent = friendlyError(err);
  }
}

// ---------- Runtime config (/config) ----------
async function loadRuntimeConfig() {
  const el = document.getElementById("config-info");
  const errEl = document.getElementById("config-error");
  el.innerHTML = `<div class="dim">loading…</div>`;
  errEl.classList.add("hidden");
  errEl.textContent = "";
  try {
    const r = await ClarityAPI.config();
    const d = r.data || {};
    el.innerHTML = [
      kv("backend", d.backend),
      kv("backend version", d.version),
      kv("library bucket", d.library_bucket),
      kv("library prefix", d.library_prefix || "(none)"),
      kv("session ttl", `${d.session_ttl}s`),
      kv("gcs ready", String(d.gcs_available)),
      kv("cors origins", (d.cors_origins || []).join(", ") || "(none)"),
    ].join("");
  } catch (err) {
    el.innerHTML = "";
    errEl.textContent = friendlyError(err);
    errEl.classList.remove("hidden");
    if (err && (err.code === "invalid_session" || err.code === "expired_session" || err.status === 401)) {
      ClarityAPI.clearSession();
      ClarityAuth.paintNavUser();
      document.getElementById("config-card").classList.add("hidden");
      document.getElementById("config-anon").classList.remove("hidden");
    }
  }
}

// ---------- helpers ----------
function kv(k, v) {
  return `<div class="kv-row"><span class="k">${escape(k)}</span><span class="v">${escape(v ?? "—")}</span></div>`;
}
function setPill(el, kind, label) {
  el.className = `pill ${kind}`;
  el.textContent = label;
}
function escape(s) { return ClarityAuth.escapeHtml(String(s)); }
function friendlyError(err) {
  if (!err) return "Something went wrong.";
  if (err.code === "network_error" || err.message === "Failed to fetch") {
    return "Could not reach the backend. Check the API URL or your network.";
  }
  if (err.status === 401) return "Your session expired — please sign in again.";
  return err.message || "Request failed.";
}
