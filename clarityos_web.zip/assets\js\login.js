document.addEventListener("DOMContentLoaded", () => {
  const tabs = document.querySelectorAll("[data-tab]");
  const forms = document.querySelectorAll("[data-form]");
  tabs.forEach((tab) => {
    tab.addEventListener("click", () => {
      tabs.forEach((t) => t.classList.remove("active"));
      tab.classList.add("active");
      const target = tab.dataset.tab;
      forms.forEach((f) => f.hidden = f.dataset.form !== target);
    });
  });

  const errSlot = document.getElementById("auth-error");
  const showError = (msg) => { errSlot.textContent = msg; errSlot.style.display = msg ? "block" : "none"; };

  document.getElementById("login-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    showError("");
    const u = e.target.username.value.trim();
    const p = e.target.password.value;
    try {
      await ClarityAPI.login(u, p);
      location.href = "console.html";
    } catch (err) {
      showError(err.message || "Sign in failed");
    }
  });

  document.getElementById("register-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    showError("");
    const u = e.target.username.value.trim();
    const p = e.target.password.value;
    if (p.length < 8) { showError("Password must be at least 8 characters"); return; }
    try {
      await ClarityAPI.register(u, p);
      location.href = "console.html";
    } catch (err) {
      showError(err.message || "Registration failed");
    }
  });
});
