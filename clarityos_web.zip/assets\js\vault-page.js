// Vault page controller. Reads from the local vault store
// (assets/js/vault.js) and renders a list with a detail modal.
// Mirrors phone/app/vault.tsx behavior on the web.

document.addEventListener("DOMContentLoaded", () => {
  const listEl = document.getElementById("vault-list");
  const emptyEl = document.getElementById("vault-empty");
  const countEl = document.getElementById("vault-count");
  const modal = document.getElementById("detail-modal");
  const modalBody = document.getElementById("detail-body");
  const modalClose = document.getElementById("detail-close");
  const closeBtn = document.getElementById("detail-close-btn");

  // Soft auth — vault is local-only, so anon users still see whatever
  // is in this browser. We add a hint about phone/web parity.
  ClarityAuth.softAuth({
    onAuthed: () => {},
    onAnon: () => {
      const hint = document.getElementById("anon-hint");
      if (hint) hint.classList.remove("hidden");
    },
  });

  render();

  modalClose.addEventListener("click", closeModal);
  if (closeBtn) closeBtn.addEventListener("click", closeModal);
  modal.addEventListener("click", (e) => { if (e.target === modal) closeModal(); });
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") closeModal(); });

  function render() {
    const items = ClarityVault.listAll();
    countEl.textContent = `${items.length} item${items.length === 1 ? "" : "s"} · on-device only`;
    if (items.length === 0) {
      emptyEl.classList.remove("hidden");
      listEl.classList.add("hidden");
      return;
    }
    emptyEl.classList.add("hidden");
    listEl.classList.remove("hidden");
    listEl.innerHTML = "";
    items.forEach((item) => {
      const row = document.createElement("button");
      row.type = "button";
      row.className = "vault-row";
      row.innerHTML = `
        <span class="v-type ${item.type}">${item.type}</span>
        <span>
          <div class="v-title">${escape(firstLine(item.content))}</div>
          <div class="v-meta">${formatMeta(item)}</div>
        </span>
        <span class="v-arrow">→</span>
      `;
      row.addEventListener("click", () => openModal(item));
      listEl.appendChild(row);
    });
  }

  function openModal(item) {
    const tags = (item.tags && item.tags.length)
      ? `<div style="margin-bottom:12px;">${item.tags.map(t => `<span class="tag-chip">${escape(t)}</span>`).join("")}</div>`
      : "";
    const provider = item.providerId
      ? `<div class="kv-row"><span class="k">provider</span><span class="v">${escape(item.providerId)}</span></div>`
      : "";
    const source = item.source
      ? `<div class="kv-row"><span class="k">source</span><span class="v">${escape(item.source)}</span></div>`
      : "";
    modalBody.innerHTML = `
      <div class="kv-row"><span class="k">type</span><span class="v">${escape(item.type)}</span></div>
      <div class="kv-row"><span class="k">created</span><span class="v">${escape(new Date(item.createdAt).toLocaleString())}</span></div>
      ${source}
      ${provider}
      <div class="kv-row"><span class="k">tags</span><span class="v">${item.tags.length ? "" : "(none)"}</span></div>
      ${tags}
      <h4 style="margin: 16px 0 8px; color: var(--text-secondary); text-transform: uppercase; font-size: 0.75rem; letter-spacing: 0.06em;">Content</h4>
      <pre class="mono" style="white-space:pre-wrap; word-break:break-word; margin:0; padding:16px; background:var(--bg-deep); border:1px solid var(--border-strong); border-radius:var(--radius-sm); color:var(--text-primary); font-size:0.85rem;">${escape(item.content)}</pre>
    `;
    modal.classList.add("open");
  }

  function closeModal() {
    modal.classList.remove("open");
  }

  function firstLine(s) {
    if (!s) return "(empty)";
    const trimmed = s.split("\n").find((l) => l.trim()) || s;
    return trimmed.length > 80 ? trimmed.slice(0, 80) + "…" : trimmed;
  }

  function formatMeta(item) {
    const ts = new Date(item.createdAt).toLocaleString();
    const tagBit = item.tags && item.tags.length ? " · " + item.tags.join(", ") : "";
    const provBit = item.providerId ? " · " + item.providerId : "";
    return escape(ts + provBit + tagBit);
  }

  function escape(s) { return ClarityAuth.escapeHtml(String(s)); }
});
