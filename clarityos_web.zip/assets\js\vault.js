// Web vault data layer — mirrors phone/lib/vault.ts in shape and intent.
//
// Architectural note: the backend has no vault routes (deliberately —
// vault is private, on-device storage). On phone that's expo-file-system;
// on web that's localStorage. The shape is identical so a future
// sync/export feature can move items between surfaces with a translation
// layer at the I/O boundary, not the model.
//
// Item shape:
//   { id, type: 'note'|'session', content, tags: string[], createdAt: ISO,
//     source?: 'ai'|'session', providerId?: 'claude'|'chatgpt'|... }
(function () {
  const NOTES_KEY = "clarityos.vault.notes";
  const SESSIONS_KEY = "clarityos.vault.sessions";

  function load(key) {
    try { return JSON.parse(localStorage.getItem(key) || "[]"); }
    catch { return []; }
  }
  function save(key, list) {
    localStorage.setItem(key, JSON.stringify(list));
  }
  function newId(prefix) {
    return prefix + "_" + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
  }
  function now() { return new Date().toISOString(); }

  function listNotes()    { return load(NOTES_KEY).slice().sort((a, b) => b.createdAt.localeCompare(a.createdAt)); }
  function listSessions() { return load(SESSIONS_KEY).slice().sort((a, b) => b.createdAt.localeCompare(a.createdAt)); }
  function listAll() {
    return [...listNotes(), ...listSessions()].sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  }

  function saveNote(input) {
    const list = load(NOTES_KEY);
    const item = { ...input, id: newId("n"), type: "note", createdAt: now(), tags: input.tags || [] };
    list.push(item);
    save(NOTES_KEY, list);
    return item;
  }

  function saveSession(input) {
    const list = load(SESSIONS_KEY);
    const item = { ...input, id: newId("s"), type: "session", createdAt: now(), tags: input.tags || [] };
    list.push(item);
    save(SESSIONS_KEY, list);
    return item;
  }

  function readItem(type, id) {
    const list = type === "note" ? load(NOTES_KEY) : load(SESSIONS_KEY);
    return list.find((x) => x.id === id) || null;
  }

  function deleteItem(type, id) {
    const key = type === "note" ? NOTES_KEY : SESSIONS_KEY;
    const next = load(key).filter((x) => x.id !== id);
    save(key, next);
  }

  function clearAll() {
    localStorage.removeItem(NOTES_KEY);
    localStorage.removeItem(SESSIONS_KEY);
  }

  window.ClarityVault = {
    listNotes, listSessions, listAll,
    saveNote, saveSession,
    readItem, deleteItem, clearAll,
  };
})();
