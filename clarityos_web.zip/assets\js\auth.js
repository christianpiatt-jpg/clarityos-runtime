// Auth helpers shared by every page. Loaded after api.js.
//
// Two flavors of "you must be signed in":
//   - requireAuth(redirect)         hard kick to /login  (use for pages that
//                                   are useless without a session)
//   - softAuth({ onAuthed, onAnon } stay on page; the controller decides
//                                   what to render. Used on protected pages
//                                   that have a meaningful unauth view.
(function () {
  function isSignedIn() { return !!ClarityAPI.getSession(); }

  function requireAuth(redirect = "login.html") {
    if (!isSignedIn()) {
      window.location.href = redirect;
      return false;
    }
    return true;
  }

  function softAuth(handlers = {}) {
    if (isSignedIn()) {
      handlers.onAuthed && handlers.onAuthed(ClarityAPI.getUser());
    } else {
      handlers.onAnon && handlers.onAnon();
    }
  }

  function paintNavUser() {
    const slot = document.querySelector("[data-user-slot]");
    if (!slot) return;
    const user = ClarityAPI.getUser();
    slot.innerHTML = user
      ? `<a href="account.html" class="muted">${escapeHtml(user)}</a>`
      : `<a href="login.html">Sign in</a>`;
  }

  function attachLogout() {
    document.querySelectorAll("[data-logout]").forEach((el) => {
      el.addEventListener("click", (e) => {
        e.preventDefault();
        ClarityAPI.logout();
        window.location.href = "index.html";
      });
    });
  }

  function markActiveNav() {
    const here = location.pathname.split("/").pop() || "index.html";
    document.querySelectorAll("nav.site-nav a").forEach((a) => {
      const href = a.getAttribute("href");
      if (href === here) a.classList.add("active");
    });
  }

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, (c) => (
      { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]
    ));
  }

  document.addEventListener("DOMContentLoaded", () => {
    paintNavUser();
    attachLogout();
    markActiveNav();
  });

  window.ClarityAuth = {
    isSignedIn, requireAuth, softAuth, paintNavUser, attachLogout, escapeHtml,
  };
})();
