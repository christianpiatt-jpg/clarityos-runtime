// Library page — placeholder for v2.4.
// The Library will become an index of saved knowledge derived from your
// Vault items; for now it's a styled empty state. No backend calls.
document.addEventListener("DOMContentLoaded", () => {
  // Soft auth — page renders for anon users too, with the same content.
  ClarityAuth.softAuth({
    onAuthed: () => {},
    onAnon: () => {},
  });
});
