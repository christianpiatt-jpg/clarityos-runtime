// Single source of truth for the backend URL.
//
// Resolution order (last non-empty wins):
//   1. `clarityos_api_base` in localStorage (per-browser override —
//      `localStorage.setItem('clarityos_api_base', '...')` and reload)
//   2. `window.CLARITYOS_API_BASE` set on the page before this script
//      (useful when the same JS bundle is hosted on multiple origins)
//   3. The DEFAULT below
//
// IMPORTANT: replace the DEFAULT with the real Cloud Run URL before
// shipping. The placeholder keeps the build deterministic — no
// secrets to invent, nothing to commit by accident.
const DEFAULT_API_BASE = "https://clarity-engine-PLACEHOLDER.run.app";

(function () {
  const fromLocal = (() => {
    try { return localStorage.getItem("clarityos_api_base"); } catch { return null; }
  })();
  const fromWindow = window.CLARITYOS_API_BASE;
  const base = (fromLocal || fromWindow || DEFAULT_API_BASE).replace(/\/+$/, "");

  window.CLARITYOS_CONFIG = {
    API_BASE: base,
    IS_PLACEHOLDER: base.includes("PLACEHOLDER"),
    VERSION: "2.4",
  };
})();
