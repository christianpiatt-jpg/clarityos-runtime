# ClarityOS Web

Static-first website for the ClarityOS runtime. Mirrors the phone UI's
visual identity (orb, dark surface, cyan↔violet accent) and talks to the
existing Cloud Run backend over HTTP — no backend route changes.

## Layout

```
web/
  index.html        landing
  login.html        sign in / sign up
  plans.html        subscription tiers
  console.html      runtime console (#c local / #G cloud, sessions, engines)
  library.html      GCS library lookup
  vault.html        encrypted personal storage (placeholder)
  account.html      session + runtime configuration
  assets/
    css/clarityos.css   design system + page styles (single stylesheet)
    js/config.js        backend URL — single config point
    js/api.js           fetch wrapper, session header, error envelope
    js/auth.js          requireAuth, nav user slot, sign-out wiring
    js/login.js         login + register controllers
    js/console.js       thread model, engine dispatch, mode toggle
    js/library.js       library page controller
    js/account.js       account page controller
  dev_proxy.py      optional local dev server with CORS-bypass proxy
```

## Configure the backend URL

`assets/js/config.js` has the production URL. For local dev you have two
options — pick whichever fits your workflow:

**Option 1 — direct, requires Cloud Run CORS update.**
Add `http://localhost:8000` to the backend's `CLARITYOS_CORS_ORIGINS`
env var (no code change, just a Cloud Run env update), then:

```bash
cd web
python -m http.server 8000
# In the browser console once:
#   localStorage.setItem('clarityos_api_base', 'https://YOUR-CLOUD-RUN-URL')
#   location.reload()
```

**Option 2 — local proxy, no backend change.** The bundled
`dev_proxy.py` serves the static site and proxies `/api/*` to Cloud Run.
The browser only ever talks to localhost, so CORS doesn't apply.

```bash
cd web
python dev_proxy.py --backend https://YOUR-CLOUD-RUN-URL
# In the browser console once:
#   localStorage.setItem('clarityos_api_base', 'http://localhost:8000/api')
#   location.reload()
```

## How it talks to the backend

Every protected call goes through `assets/js/api.js`. The session token
returned by `POST /login` (or `POST /register`) is stored in
`localStorage` under `clarityos_session` and sent as `X-Session-ID` on
every subsequent call. Routes used:

| Route | Method | Auth | Where |
|---|---|---|---|
| `/login`, `/register` | POST | no | `login.html` |
| `/me`, `/config` | GET | yes | `account.html` |
| `/markov`, `/galileo`, `/tizzy` | POST | yes | `console.html` |
| `/library` | POST | yes | `library.html` |
| `/health` | GET | no | `console.html` (cloud-node probe) |

The runtime never invents new routes. If `console.html` shows a thread
list, those threads are local-only — they live in `localStorage` under
`clarityos_threads`. The backend's session model is the auth session,
not a conversation thread.

## Deploy

The site is static. Pick whichever host you prefer:

- **Cloud Storage static website**: `gsutil rsync -r web gs://YOUR-BUCKET/`
- **Cloud Run as a sibling service**: serve via nginx in a tiny container.
- **Netlify / Cloudflare Pages / GitHub Pages**: drop the `web/` folder.
- **WordPress (existing pro-mediations.com)**: see WordPress conversion below.

For any of these you need to:

1. Set the production backend URL in `assets/js/config.js` (replace
   `clarity-engine-PLACEHOLDER.run.app`).
2. Make sure your origin is in the backend's `CLARITYOS_CORS_ORIGINS`
   env var.

## WordPress conversion

The directory layout already follows the WP theme convention
(`wp-content/themes/clarityos/`). To convert:

1. Copy `web/` to `wp-content/themes/clarityos/`.
2. Add a `style.css` header at the top of `assets/css/clarityos.css`
   (or as a thin shim that `@import`s it):

   ```css
   /*
   Theme Name: ClarityOS
   Version: 0.1
   */
   ```

3. Convert each `*.html` to a matching `page-*.php` template by
   replacing the `<!DOCTYPE html>...<head>` opener with
   `<?php get_header(); ?>` and the trailing `</body></html>` with
   `<?php get_footer(); ?>`. Move the shared `<header>` and `<footer>`
   blocks into `header.php` / `footer.php`.
4. Enqueue scripts via `functions.php` instead of inline `<script>`
   tags so WP's caching plugins behave.
5. Add WP pages whose slugs match the templates.

The HTML/CSS/JS works unchanged in the converted theme — only the
header/footer wiring moves.

## Visual identity notes

The design tokens in `assets/css/clarityos.css` (`:root` block) are the
single source of truth. The mobile app at `../phone/lib/theme.ts`
mirrors them verbatim — change one, change both.

If you have authoritative tokens from Gemini's phone design (exact
hexes, specific font, orb gradient stops), swap them in at `:root` and
in `phone/lib/theme.ts`. Every surface inherits from those two files.
