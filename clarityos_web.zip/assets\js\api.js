// ClarityOS web API client. Mirrors phone/lib/api.ts so behavior is
// identical across surfaces. All authenticated calls send X-Session-ID;
// the session id is persisted in localStorage as `clarityos_session`.

(function () {
  const SESSION_KEY = "clarityos_session";
  const USER_KEY = "clarityos_user";

  function base() {
    return window.CLARITYOS_CONFIG.API_BASE.replace(/\/+$/, "");
  }

  function getSession() {
    return localStorage.getItem(SESSION_KEY) || null;
  }

  function getUser() {
    return localStorage.getItem(USER_KEY) || null;
  }

  function setSession(sessionId, username) {
    if (sessionId) localStorage.setItem(SESSION_KEY, sessionId);
    if (username) localStorage.setItem(USER_KEY, username);
  }

  function clearSession() {
    localStorage.removeItem(SESSION_KEY);
    localStorage.removeItem(USER_KEY);
  }

  async function request(path, { method = "GET", body, auth = true } = {}) {
    const headers = { "Content-Type": "application/json" };
    if (auth) {
      const sid = getSession();
      if (!sid) throw new ApiError("missing_session", "Not signed in", 401);
      headers["X-Session-ID"] = sid;
    }
    const res = await fetch(base() + path, {
      method,
      headers,
      body: body ? JSON.stringify(body) : undefined,
    });
    let data = null;
    try { data = await res.json(); } catch (_) { /* non-JSON or empty */ }
    if (!res.ok || (data && data.ok === false)) {
      const code = (data && data.error) || "http_error";
      const msg = (data && data.message) || res.statusText || "Request failed";
      throw new ApiError(code, msg, res.status, data);
    }
    return data;
  }

  class ApiError extends Error {
    constructor(code, message, status, body) {
      super(message);
      this.code = code;
      this.status = status;
      this.body = body;
    }
  }

  // ---------- Auth ----------
  async function login(username, password) {
    const data = await request("/login", {
      method: "POST",
      body: { username, password },
      auth: false,
    });
    setSession(data.session_id, data.user);
    return data;
  }

  async function register(username, password) {
    const data = await request("/register", {
      method: "POST",
      body: { username, password },
      auth: false,
    });
    setSession(data.session_id, data.user);
    return data;
  }

  function logout() { clearSession(); }

  // ---------- Account ----------
  const me = () => request("/me");
  const config = () => request("/config");

  // ---------- Engines ----------
  const markov = (text, meta) => request("/markov", { method: "POST", body: { text, meta } });
  const galileo = (text, meta) => request("/galileo", { method: "POST", body: { text, meta } });
  const tizzy = (text, meta) => request("/tizzy", { method: "POST", body: { text, meta } });
  const library = (path, meta) => request("/library", { method: "POST", body: { text: path, meta } });

  // ---------- Public ----------
  const health = () => request("/health", { auth: false });

  window.ClarityAPI = {
    ApiError,
    getSession, getUser, setSession, clearSession,
    login, register, logout,
    me, config,
    markov, galileo, tizzy, library,
    health,
  };
})();
