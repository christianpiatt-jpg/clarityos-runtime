// Plans page controller — current tier display + "Upgrade" stubs.
//
// The backend's /me endpoint does not currently expose the user's tier;
// when it does (e.g. add `tier` to the /me envelope), update readTier()
// and remove the "default" suffix on the badge.

const TIERS = ["free", "practitioner", "org"];

document.addEventListener("DOMContentLoaded", () => {
  const placeholderBanner = document.getElementById("placeholder-banner");
  if (window.CLARITYOS_CONFIG.IS_PLACEHOLDER && placeholderBanner) {
    placeholderBanner.classList.remove("hidden");
  }

  paintCurrentTier(); // synchronous, default state
  loadCurrentTier();  // async refresh once /me responds (auth only)

  document.querySelectorAll("[data-upgrade]").forEach((btn) => {
    btn.addEventListener("click", (e) => {
      e.preventDefault();
      const target = btn.dataset.upgrade;
      // Placeholder for the real billing flow. Wire to Stripe Checkout
      // (or whatever provider is chosen) when the subscription system
      // lands. For now: log + toast.
      console.info("[plans] upgrade requested →", target);
      flashBanner(`Upgrade to "${target}" — billing flow not wired yet.`);
    });
  });
});

async function loadCurrentTier() {
  if (!ClarityAuth.isSignedIn()) return;
  try {
    const me = await ClarityAPI.me();
    // TODO: when /me returns `tier`, switch to me.tier and drop the default.
    const tier = readTier(me) || "free";
    paintCurrentTier(tier, /*authoritative=*/ Boolean(me.tier));
  } catch (err) {
    if (err && (err.code === "invalid_session" || err.status === 401)) {
      ClarityAPI.clearSession();
      ClarityAuth.paintNavUser();
    }
    // Fall through silently — Plans is informational; the page still works.
  }
}

function readTier(me) {
  // Tolerant of future shapes: top-level `tier`, nested under `.data`, or absent.
  return (me && (me.tier || (me.data && me.data.tier))) || null;
}

function paintCurrentTier(tier = "free", authoritative = false) {
  document.querySelectorAll(".plan-card").forEach((c) => c.classList.remove("current"));
  const card = document.querySelector(`.plan-card[data-tier="${tier}"]`);
  if (card) card.classList.add("current");

  const badge = document.getElementById("tier-badge");
  if (badge) {
    badge.textContent = `Current tier: ${tier}${authoritative ? "" : " (default)"}`;
  }
}

function flashBanner(msg) {
  const el = document.getElementById("plans-banner");
  if (!el) return alert(msg);
  el.textContent = msg;
  el.classList.remove("hidden");
  setTimeout(() => el.classList.add("hidden"), 3500);
}
