// Account page controller — soft auth.
// Renders an inline sign-in CTA for unauth users instead of redirecting,
// and only loads /me when there's a session token.
document.addEventListener("DOMContentLoaded", () => {
  const authedEl = document.getElementById("authed-view");
  const anonEl = document.getElementById("anon-view");
  const meEl = document.getElementById("me-info");
  const errEl = document.getElementById("account-error");
  const placeholderBanner = document.getElementById("placeholder-banner");

  if (window.CLARITYOS_CONFIG.IS_PLACEHOLDER && placeholderBanner) {
    placeholderBanner.classList.remove("hidden");
  }

  ClarityAuth.softAuth({
    onAuthed: () => {
      anonEl.classList.add("hidden");
      authedEl.classList.remove("hidden");
      load();
    },
    onAnon: () => {
      authedEl.classList.add("hidden");
      anonEl.classList.remove("hidden");
    },
  });

  async function load() {
    meEl.innerHTML = `<div class="dim">loading…</div>`;
    errEl.classList.add("hidden");
    errEl.textContent = "";
    try {
      const me = await ClarityAPI.me();
      meEl.innerHTML = `
        <div class="kv-row"><span class="k">user</span><span class="v">${escape(me.user)}</span></div>
        <div class="kv-row"><span class="k">session id</span><span class="v">${escape(me.session_id.slice(0, 12))}…</span></div>
      `;
    } catch (err) {
      meEl.innerHTML = "";
      errEl.textContent = friendlyError(err);
      errEl.classList.remove("hidden");
      // If the server says our session is invalid/expired, clear it so the
      // next reload shows the soft sign-in CTA.
      if (err && (err.code === "invalid_session" || err.code === "expired_session" || err.status === 401)) {
        ClarityAPI.clearSession();
        ClarityAuth.paintNavUser();
        authedEl.classList.add("hidden");
        anonEl.classList.remove("hidden");
      }
    }
  }

  function friendlyError(err) {
    if (!err) return "Something went wrong.";
    if (err.code === "network_error" || err.message === "Failed to fetch") {
      return "Could not reach the backend. Check the API URL in /console or your network.";
    }
    if (err.status === 401) return "Your session expired — please sign in again.";
    return err.message || "Request failed.";
  }

  function escape(s) { return ClarityAuth.escapeHtml(s); }
});
