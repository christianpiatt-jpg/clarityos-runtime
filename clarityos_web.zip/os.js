/* ==========================================================
   ClarityOS — Gemini integration wiring
   COMING SOON LOCKOUT MODE.
   Active: mobile overlay, #c local engine, #G structured compute.
   Disabled (lockout): /login, /api/account/status,
   /api/vault/save, /api/vault/list, library list.
   Endpoint names for #c and #G are fixed by the integration
   spec — do not modify.
   ========================================================== */

(function () {
  "use strict";

  /* ---------- Active endpoints (engine wiring only) ---------- */
  var EP = {
    cLocal:   "/api/c/local",
    gCompute: "/api/g/compute"
  };

  /* ---------- Helpers ---------- */
  function $(sel, root) { return (root || document).querySelector(sel); }
  function $$(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

  function metaLine(text) {
    return '<div class="meta-line">' + escapeHtml(text) + '</div>';
  }
  function responseLine(text) {
    return '<div class="output-response">' + escapeHtml(text) + '</div>';
  }
  function escapeHtml(s) {
    return String(s == null ? "" : s)
      .replace(/&/g, "&amp;").replace(/</g, "&lt;")
      .replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;");
  }
  function fmtTime(d) {
    d = d || new Date();
    var pad = function (n) { return n < 10 ? "0" + n : "" + n; };
    return pad(d.getHours()) + ":" + pad(d.getMinutes()) + ":" + pad(d.getSeconds());
  }
  function postJSON(url, body) {
    return fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body || {}),
      credentials: "same-origin"
    }).then(function (r) {
      if (!r.ok) throw new Error("HTTP " + r.status);
      return r.json().catch(function () { return {}; });
    });
  }

  /* ---------- Mobile overlay ---------- */
  function bindMobileOverlay() {
    var trigger = $(".mobile-trigger");
    var overlay = $(".mobile-overlay");
    if (!trigger || !overlay) return;
    trigger.addEventListener("click", function () { overlay.classList.add("open"); });
    var closeBtn = $(".mobile-overlay-close", overlay);
    if (closeBtn) closeBtn.addEventListener("click", function () { overlay.classList.remove("open"); });
    $$("a", overlay).forEach(function (a) {
      a.addEventListener("click", function () { overlay.classList.remove("open"); });
    });
  }

  /* ---------- Console engines (#c / #G) — ACTIVE ---------- */
  function bindConsole() {
    var panels = $$('[data-engine]');
    if (!panels.length) return;

    panels.forEach(function (panel) {
      var engine = panel.getAttribute("data-engine"); // "c" or "G"
      var output = $(".output-window", panel);
      var input  = $(".input-bar input", panel);
      var execBtn = panel.querySelector('[data-action="execute"]');
      var saveBtn = panel.querySelector('[data-action="save"]');
      var discardBtn = panel.querySelector('[data-action="discard"]');

      function appendOutput(html) {
        if (!output) return;
        output.insertAdjacentHTML("beforeend", html);
        output.scrollTop = output.scrollHeight;
      }

      function execute() {
        if (!input || !output) return;
        var prompt = (input.value || "").trim();
        if (!prompt) return;
        var endpoint = engine === "G" ? EP.gCompute : EP.cLocal;
        appendOutput(metaLine("[" + fmtTime() + "] " + endpoint + " ← input"));
        execBtn && execBtn.setAttribute("disabled", "true");
        postJSON(endpoint, { prompt: prompt })
          .then(function (data) {
            var text = (data && (data.response || data.output || data.text)) || "(no output)";
            panel.dataset.lastOutput = text;
            panel.dataset.lastPrompt = prompt;
            appendOutput(responseLine(text));
            appendOutput(metaLine("[" + fmtTime() + "] envelope only — no content stored"));
          })
          .catch(function (err) {
            appendOutput(metaLine("[" + fmtTime() + "] error: " + err.message));
          })
          .then(function () {
            execBtn && execBtn.removeAttribute("disabled");
            input.value = "";
            input.focus();
          });
      }

      // [Save to Remember] is part of the lockout — vault save endpoint disabled.
      function saveLocked() {
        appendOutput(metaLine("[" + fmtTime() + "] save unavailable — vault is in Coming Soon mode"));
      }

      function discard() {
        if (!output) return;
        output.innerHTML = responseLine("System ready. Awaiting " + (engine === "G" ? "structured compute request." : "local input vector."));
        delete panel.dataset.lastOutput;
        delete panel.dataset.lastPrompt;
      }

      if (execBtn) execBtn.addEventListener("click", execute);
      if (input) input.addEventListener("keydown", function (e) { if (e.key === "Enter") execute(); });
      if (saveBtn) saveBtn.addEventListener("click", saveLocked);
      if (discardBtn) discardBtn.addEventListener("click", discard);
    });
  }

  /* ---------- Vault list — DISABLED (Coming Soon) ---------- */
  function bindVaultList() {
    var host = $('[data-vault-list]');
    if (!host) return;
    host.innerHTML = '<div class="empty-line">Vault — Coming Soon</div>';
  }

  /* ---------- Library list — DISABLED (Coming Soon) ---------- */
  function bindLibraryList() {
    var host = $('[data-library-list]');
    if (!host) return;
    host.innerHTML = '<div class="empty-line">Local Library — Coming Soon</div>';
  }

  /* ---------- Account status — DISABLED (Coming Soon) ----------
     Note: account.html now ships a static Coming Soon module and
     does not include [data-account-status]. This stub stays as a
     no-op so the file is safe to drop on any page. */
  function bindAccount() {
    var host = $('[data-account-status]');
    if (!host) return;
    host.innerHTML = '<div class="empty-line">Operator Profile — Coming Soon</div>';
  }

  /* ---------- Login — DISABLED (Coming Soon) ----------
     login.html no longer includes a form. Any stray form posting
     to /login is intercepted and blocked. */
  function disableLoginForms() {
    $$('form[action="/login"]').forEach(function (f) {
      f.addEventListener("submit", function (e) {
        e.preventDefault();
        e.stopPropagation();
      });
    });
  }

  /* ---------- Bootstrap ---------- */
  document.addEventListener("DOMContentLoaded", function () {
    bindMobileOverlay();
    bindConsole();        // #c / #G remain active
    bindVaultList();      // lockout
    bindLibraryList();    // lockout
    bindAccount();        // lockout
    disableLoginForms();  // lockout
  });
})();
