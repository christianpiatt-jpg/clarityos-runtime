<?php get_header(); ?>

<div class="layer">
    <h1>GalileOnline</h1>
    <p>New theme scaffold is working.</p>
</div>

<?php get_footer(); ?>